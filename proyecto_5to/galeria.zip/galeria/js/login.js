$(document).ready(function () {
  $("#enviarLogin").click(() => {
    $.ajax({
      url: "http://localhost/galeria/php/login.php",
      data: {
        usuario: $("#loginUsuario").val(),
        clave: $("#loginClave").val(),
      },
      type: "post",
      success: function (result) {
        if (result === "ok") {
          window.location.href = "./subir.php";
        }
      },
    });
  });
});
